<?php
	/**
	* Chinese language file.
	*/

	//Basic
	$plugin_lang['strplugindescription'] = 'Report plugin';
	$plugin_lang['strnoreportsdb'] = '你不能创建报告数据库。 请参阅INSTALL文件。';

	// Reports
	$plugin_lang['strreport'] = '报表';
	$plugin_lang['strreports'] = '报表';
	$plugin_lang['strshowallreports'] = '显示所有报表';
	$plugin_lang['strnoreports'] = '查无报表。';
	$plugin_lang['strcreatereport'] = '创建报表';
	$plugin_lang['strreportdropped'] = '报表已删除。';
	$plugin_lang['strreportdroppedbad'] = '报表删除失败。';
	$plugin_lang['strconfdropreport'] = '确定要删除报表"%s"吗？';
	$plugin_lang['strreportneedsname'] = '必须指定报表名称。';
	$plugin_lang['strreportneedsdef'] = '必须给报表指定SQL。';
	$plugin_lang['strreportcreated'] = '报表已保存。';
	$plugin_lang['strreportcreatedbad'] = '报表保存失败。';
?>
